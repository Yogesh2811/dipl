var daemon_8h =
[
    [ "Daemon", "class_daemon.html", "class_daemon" ],
    [ "PARSER_COUNT", "daemon_8h.html#aa1cd50a8861f4b52c4f177b71ad026e4", null ],
    [ "BYTE", "daemon_8h.html#a4ae1dab0fb4b072a66584546209e7d58", null ]
];