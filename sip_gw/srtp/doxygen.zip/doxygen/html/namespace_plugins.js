var namespace_plugins =
[
    [ "Codec", "struct_plugins_1_1_codec.html", "struct_plugins_1_1_codec" ]
];