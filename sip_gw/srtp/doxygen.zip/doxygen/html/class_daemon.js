var class_daemon =
[
    [ "Daemon", "class_daemon.html#aa2876769e81613f2d3685dd805a8a6ca", null ],
    [ "~Daemon", "class_daemon.html#ae10170ea962e99bdea6c8074af7e13ba", null ],
    [ "operator()", "class_daemon.html#a64653e31c9fb91d1da820d09a48450c9", null ],
    [ "parse_msg", "class_daemon.html#acc90ffc47849d51abcee3046e947bce5", null ],
    [ "set_interface", "class_daemon.html#a7ae4e6be5aff344b13a19d25c319b1a0", null ],
    [ "stop", "class_daemon.html#a62323bab13cc3b7b13b41bce531281a9", null ]
];