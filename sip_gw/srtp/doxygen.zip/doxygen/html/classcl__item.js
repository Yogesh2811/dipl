var classcl__item =
[
    [ "iv_gpu", "classcl__item.html#a0d8deb281ca60995955d57fa5e2917fe", null ],
    [ "payload_dst", "classcl__item.html#a2c63dab735547bd1b28072a906ae834a", null ],
    [ "payload_src", "classcl__item.html#af354333a97f5dab298a8a24a44793604", null ],
    [ "rk", "classcl__item.html#a4d72ad2291ffce1c6525a52d4d51c95e", null ],
    [ "t1", "classcl__item.html#ad9c3cdc07b870b62686c4c13f5b38e3f", null ],
    [ "t2", "classcl__item.html#a243f13a40666caee7a53b71a5808968a", null ]
];