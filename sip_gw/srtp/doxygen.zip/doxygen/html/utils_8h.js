var utils_8h =
[
    [ "LOG_ERROR", "utils_8h.html#ad4a9117ce894e3319e903142347a0f63", null ],
    [ "LOG_MSG", "utils_8h.html#a82499e7f0ef5272566e3578a05c29369", null ],
    [ "get_time", "utils_8h.html#af7ab092ab10d65db3b9051a12420fa52", null ]
];