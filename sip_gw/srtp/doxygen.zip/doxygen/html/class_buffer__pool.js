var class_buffer__pool =
[
    [ "Buffer_pool", "class_buffer__pool.html#af7e081c30cbd8fe99cc44fb517c2cf04", null ],
    [ "~Buffer_pool", "class_buffer__pool.html#a9adc28fef93c2bd7a2699a82287aff93", null ],
    [ "get_buffer_id", "class_buffer__pool.html#a855bdfbe5d7a7e2ef00ea00385fde266", null ],
    [ "get_item", "class_buffer__pool.html#a6114d398ffca722d84c1763f2f8f1fe1", null ],
    [ "get_pool_size", "class_buffer__pool.html#a5bf2abceb9cfdf2b4b23e8322cd891ca", null ],
    [ "release_buffer", "class_buffer__pool.html#acf259ab0d134726264b8c8069751c9b9", null ]
];