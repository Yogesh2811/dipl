var searchData=
[
  ['cleanup',['cleanup',['../namespace_g_p_u.html#ad43d80b95122952f3a579146c72829c1',1,'GPU::cleanup()'],['../namespace_plugins.html#a2f744ab4293e326bd999651af76412e8',1,'Plugins::cleanup()']]],
  ['clerrorstring',['CLErrorString',['../cl__util_8h.html#a2fa7c46bb8321eb9cc9e02aaf1598b88',1,'cl_util.cpp']]],
  ['create_5fstream',['create_stream',['../class_r_t_p__interface.html#aa3a46ece6d7780fead90bd04a5cf42a8',1,'RTP_interface']]]
];
