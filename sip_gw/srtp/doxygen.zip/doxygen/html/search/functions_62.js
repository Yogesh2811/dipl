var searchData=
[
  ['buffer_5fpool',['Buffer_pool',['../class_buffer__pool.html#af7e081c30cbd8fe99cc44fb517c2cf04',1,'Buffer_pool']]]
];
