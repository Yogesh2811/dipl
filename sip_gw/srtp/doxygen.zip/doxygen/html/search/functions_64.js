var searchData=
[
  ['daemon',['Daemon',['../class_daemon.html#aa2876769e81613f2d3685dd805a8a6ca',1,'Daemon']]]
];
