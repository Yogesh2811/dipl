var searchData=
[
  ['daemon_2eh',['daemon.h',['../daemon_8h.html',1,'']]]
];
