var searchData=
[
  ['cc',['cc',['../struct_s_r_t_p_1_1header.html#a1e0266422baa62f2f1d42a43bdc70769',1,'SRTP::header']]],
  ['cl_5fitem',['cl_item',['../classcl__item.html',1,'']]],
  ['cl_5futil_2eh',['cl_util.h',['../cl__util_8h.html',1,'']]],
  ['cleanup',['cleanup',['../namespace_g_p_u.html#ad43d80b95122952f3a579146c72829c1',1,'GPU::cleanup()'],['../namespace_plugins.html#a2f744ab4293e326bd999651af76412e8',1,'Plugins::cleanup()']]],
  ['clerrorstring',['CLErrorString',['../cl__util_8h.html#a2fa7c46bb8321eb9cc9e02aaf1598b88',1,'cl_util.cpp']]],
  ['codec',['Codec',['../struct_plugins_1_1_codec.html',1,'Plugins']]],
  ['columns',['COLUMNS',['../aes_8h.html#a06c6c391fc11d106e9909f0401b255b1',1,'aes.h']]],
  ['create_5fstream',['create_stream',['../class_r_t_p__interface.html#aa3a46ece6d7780fead90bd04a5cf42a8',1,'RTP_interface']]],
  ['csrc',['csrc',['../struct_s_r_t_p_1_1header.html#a9ac0e5de3b2ac4aaa8a793d864c9b2d0',1,'SRTP::header']]]
];
