var searchData=
[
  ['rk',['rk',['../classcl__item.html#a4d72ad2291ffce1c6525a52d4d51c95e',1,'cl_item']]],
  ['roc',['roc',['../class_s_r_t_p__stream.html#aeb70be6789647302447fbd1c718c87bf',1,'SRTP_stream']]]
];
