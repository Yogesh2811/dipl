var searchData=
[
  ['from_5fraw',['from_raw',['../struct_plugins_1_1_codec.html#aeb2139a078a4c32515ec2d6797c0f153',1,'Plugins::Codec']]]
];
