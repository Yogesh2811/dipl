var searchData=
[
  ['plugins',['Plugins',['../namespace_plugins.html',1,'']]]
];
