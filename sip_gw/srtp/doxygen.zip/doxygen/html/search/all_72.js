var searchData=
[
  ['release_5fbuffer',['release_buffer',['../class_buffer__pool.html#acf259ab0d134726264b8c8069751c9b9',1,'Buffer_pool']]],
  ['release_5fstream',['release_stream',['../class_r_t_p__interface.html#a82efe7c9efddc9d1e60a05e9e1aadc43',1,'RTP_interface']]],
  ['rk',['rk',['../classcl__item.html#a4d72ad2291ffce1c6525a52d4d51c95e',1,'cl_item']]],
  ['roc',['roc',['../class_s_r_t_p__stream.html#aeb70be6789647302447fbd1c718c87bf',1,'SRTP_stream']]],
  ['round_5fkey_5fsize',['ROUND_KEY_SIZE',['../aes_8h.html#ae7cc42e7601c1c59bffbf4b144971610',1,'aes.h']]],
  ['rounds',['ROUNDS',['../aes_8h.html#a69479655ab94c875413d38689002ff98',1,'aes.h']]],
  ['rows',['ROWS',['../aes_8h.html#a3cfd3aa62338d12609f6d65bce97e9cd',1,'aes.h']]],
  ['rtp_5finterface',['RTP_interface',['../class_r_t_p__interface.html',1,'RTP_interface'],['../class_r_t_p__interface.html#a4535f8111def6f55a9ddc89fcab4fbc5',1,'RTP_interface::RTP_interface()']]],
  ['rtp_5finterface_2eh',['rtp_interface.h',['../rtp__interface_8h.html',1,'']]],
  ['rtp_5fitem',['RTP_item',['../class_r_t_p__item.html',1,'RTP_item'],['../class_r_t_p__item.html#a7c529f88315c3e655769ddef569b591a',1,'RTP_item::RTP_item()']]]
];
