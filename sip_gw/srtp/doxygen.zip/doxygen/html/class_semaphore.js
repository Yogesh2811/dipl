var class_semaphore =
[
    [ "Semaphore", "class_semaphore.html#ae32c955336ae9e60e20a3facde270714", null ],
    [ "notify", "class_semaphore.html#a04d9259eb2fa93e9a64eaf78290f023a", null ],
    [ "wait", "class_semaphore.html#a85500356c2f7d1057d4568227e7f35b7", null ]
];