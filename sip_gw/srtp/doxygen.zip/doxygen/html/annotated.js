var annotated =
[
    [ "AES", "namespace_a_e_s.html", null ],
    [ "GPU", "namespace_g_p_u.html", null ],
    [ "Plugins", "namespace_plugins.html", "namespace_plugins" ],
    [ "SRTP", "namespace_s_r_t_p.html", "namespace_s_r_t_p" ],
    [ "Buffer_pool", "class_buffer__pool.html", "class_buffer__pool" ],
    [ "cl_item", "classcl__item.html", "classcl__item" ],
    [ "Daemon", "class_daemon.html", "class_daemon" ],
    [ "Parser_interface", "class_parser__interface.html", "class_parser__interface" ],
    [ "RTP_interface", "class_r_t_p__interface.html", "class_r_t_p__interface" ],
    [ "RTP_item", "class_r_t_p__item.html", "class_r_t_p__item" ],
    [ "Semaphore", "class_semaphore.html", "class_semaphore" ],
    [ "SRTP_parser", "class_s_r_t_p__parser.html", "class_s_r_t_p__parser" ],
    [ "SRTP_stream", "class_s_r_t_p__stream.html", "class_s_r_t_p__stream" ]
];