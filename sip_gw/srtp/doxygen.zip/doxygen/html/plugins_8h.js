var plugins_8h =
[
    [ "Codec", "struct_plugins_1_1_codec.html", "struct_plugins_1_1_codec" ],
    [ "BYTE", "plugins_8h.html#a4ae1dab0fb4b072a66584546209e7d58", null ],
    [ "CBYTE", "plugins_8h.html#a1b1c80c194d7e469dd0b14630f283620", null ],
    [ "cleanup", "plugins_8h.html#a2f744ab4293e326bd999651af76412e8", null ],
    [ "init", "plugins_8h.html#a9bba2161bbbcf66c3e9fb5068f2427de", null ],
    [ "transcode", "plugins_8h.html#ad9e83e3e36c5336b2850cd31fd103859", null ]
];