var struct_plugins_1_1_codec =
[
    [ "encoding_name", "struct_plugins_1_1_codec.html#acaa5e1a65439440f15e40d23b4ca4d08", null ],
    [ "from_raw", "struct_plugins_1_1_codec.html#aeb2139a078a4c32515ec2d6797c0f153", null ],
    [ "PT", "struct_plugins_1_1_codec.html#a8fe38f1f4ab34fc6ae1e8b99e7d13d87", null ],
    [ "to_raw", "struct_plugins_1_1_codec.html#a0149aa5ce13ac640eb0be78eee3f4450", null ],
    [ "transcode", "struct_plugins_1_1_codec.html#a8103fb3546514a752106136b5fefbc99", null ]
];