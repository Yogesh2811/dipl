var class_parser__interface =
[
    [ "parse_msg", "class_parser__interface.html#a188ae93744aaf50e314ceb9c1b77b72b", null ]
];